function [ ] = startup()
%STARTUP.M Summary of this function goes here
%   Detailed explanation goes here

ones(10)*ones(10);
 
end

