
close all;
Data=load('FinalUniData.mat');
train=Data.train;
val=Data.val;
test=Data.test;
b=size(train,1);

trainin=train(:,1);
valin=val(:,1);
testin=test(:,1);

trainout=train(:,2);
valout=val(:,2);
testout=test(:,2);
trainactual=train(:,3);
trainactual=train(:,3)+0.3.*ones(size(trainactual,1),1);
valactual=val(:,3);
testactual=test(:,3);

valerror(100,1)=zeros;
testerror(100,1)=zeros;
trainerror(100,1)=zeros;
n=1;
for m=0.01:0.01:1
nuvalue(n,1)=m;
    
    str=['-s 4 -t 2 -g 16.5 -c 1 -n ' num2str(m)];
model=svmtrain(trainout,trainin,str);
[predictedVal, MSE, Prob_Val]=svmpredict(trainout,trainin,model);
trainerror(n,1)=MSE(2,1);

[predictedVal, MSE, Prob_Val]=svmpredict(valout,valin,model);
valerror(n,1)=MSE(2,1);

[predictedVal, MSE, Prob_Val]=svmpredict(testout,testin,model);
testerror(n,1)=MSE(2,1);
n=n+1;


end

c=1;
%epsilon=   0.297932;
epsilon=0.245525;


 str=['-s 4 -t 2 -g 16.5 -c 1 -n ' num2str(0.3)];
model=svmtrain(trainout,trainin,str);

[out, MSE, Prob_Val]=svmpredict(trainout,trainin,model);


[out, MSE, Prob_Val]=svmpredict(trainout,trainin,model);


out1=out-epsilon.*ones(size(out,1),1);
out2=out+epsilon.*ones(size(out,1),1);

figure;
xx = linspace(min(trainin),max(trainin),100);
    
plot(trainin,trainout,'.b');hold on;
yy2 = spline(trainin,trainactual,xx); 
	plot(xx,yy2,'LineWidth',3,'color','m')
    
    

h=figure;hold on;
	
	xx = linspace(min(trainin),max(trainin),100);
    
    yy2 = spline(trainin,out1,xx); 
	plot(xx,yy2,'LineWidth',3,'color','k')
    
    
    %yy = spline(trainin,trainout,xx); 
    %plot(trainin,trainout,'*',xx,yy,'LineWidth',3,'color','r')
    scatter(trainin,trainout,'o', 'Filled')
     
    yy2 = spline(trainin,out,xx); 
	plot(xx,yy2,'LineWidth',3,'color','b')
    
    
    
     supvectors = model.sv_indices;
supcoefficients = model.sv_coef;

temp =      supvectors(1,:);
supvectors(1,:)=supvectors(9,:);
supvectors(9,:)=temp;


temp =      supcoefficients(1,:);
supcoefficients(1,:)=supcoefficients(9,:);
supcoefficients(9,:)=temp;

for j = 1:size(supvectors,1)
    if(supcoefficients(j,1)== c)
      plot(trainin(supvectors(j,1),1),trainout(supvectors(j,1),1),'g*','MarkerSize', 15);
    else
     plot(trainin(supvectors(j,1),1),trainout(supvectors(j,1),1),'m*','MarkerSize', 15);
    end
end

    yy2 = spline(trainin,out2,xx); 
	plot(xx,yy2,'LineWidth',3,'color','k')
    
	
%     yy2 = spline(trainin,trainactual,xx); 
% 	plot('LineWidth',2,'color','b')
%     
    yy2 = spline(trainin,trainactual,xx); 
	plot(xx,yy2,'LineWidth',3,'color','m')
    
    
   

    
   
    xlabel('X Values'); % x-axis label
	ylabel('Y Values(Estimated)'); % y-axis label
    legend('Epsilon Tube','Train Data','Predicted','Bounded Support Vectors','Unbounded Support Vectors');
	saveas(h,'trainregression.jpeg');



[testpredict, MSE, Prob_Val]=svmpredict(testout,testin,model);


[valpredict, MSE, Prob_Val]=svmpredict(valout,valin,model);



