Data=load('TwoMoons.mat');
x=Data.Labeledtrain1;
y=Data.labeltarget;
x2=Data.test1;
y2=Data.TestTargets1;

%model=svmtrain(y,x,'-s 1 -t 1 -d 2 -r 0.55 -n 0.23')
model=svmtrain(y,x,'-s 1 -t 2 -g 0.069 -n 0.23 -b 1 ');
[predicted,accuracy,prob_val]=svmpredict(y2,x2,model,'-b 1');
