n=1;
for m=0.1:0.01:1
nuvalue(n,1)=m;
    
    str=['-s 4 -t 2 -g 16.5 -c 1 -n ' num2str(m)];
model=svmtrain(trainout,trainin,str);
[predictedVal, MSE, Prob_Val]=svmpredict(trainout,trainin,model);
trainerror(n,1)=MSE(2,1);

[predictedVal, MSE, Prob_Val]=svmpredict(valout,valin,model);
valerror(n,1)=MSE(2,1);

[predictedVal, MSE, Prob_Val]=svmpredict(testout,testin,model);
testerror(n,1)=MSE(2,1);
n=n+1;


end


%Complexity Vs Error
h=figure;
hold on;

kvalues=nuvalue;

err=trainerror;
plot(kvalues,err,'-b','LineWidth',3);
%scatter(kvalues,err,'*m');

testerr=testerror;
plot(kvalues,testerr,'-g','LineWidth',3);
%scatter(kvalues,testerr,'*m');

valerr=valerror;
plot(kvalues,valerr,'-r','LineWidth',3);
%scatter(kvalues,valerr,'*m');



xlabel('nu Value'); % x-axis label
ylabel('Mean Squared Error'); % y-axis label
title('nu Vs Mean Squared Error');
legend('Train Error','Validation Error','Test Error'); 

