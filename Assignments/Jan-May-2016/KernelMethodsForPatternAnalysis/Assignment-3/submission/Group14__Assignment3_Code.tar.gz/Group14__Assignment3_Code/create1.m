total=[l;u;t];
trsize=size(total,1);
%Kernel(trsize,trsize)=zeros;
% for i=1:trsize
%     for j=1:trsize
%         kij=exp(-0.005*(norm(total(i,:)-total(j,:))).^2);
%         kii=sqrt(exp(-0.005*(norm(total(i,:)-total(i,:))).^2));
%         kjj=sqrt(exp(-0.005*(norm(total(j,:)-total(j,:))).^2));
%         Kernel(i,j)=sqrt(kij/(kii*kjj));
%     end
% end
% figure;
% %imshow(Kernel);
% W=Kernel;


dist(trsize,trsize)=zeros;
eps=0.78;
for i=1:trsize
    for j=1:trsize
        dist(i,j)=norm(total(i,:)-total(j,:));
        if(dist(i,j)<=eps)
            W1(i,j)=1;
        else
            W1(i,j)=0;
        end
    end
end

%W1=dist;
%imshow(W1);