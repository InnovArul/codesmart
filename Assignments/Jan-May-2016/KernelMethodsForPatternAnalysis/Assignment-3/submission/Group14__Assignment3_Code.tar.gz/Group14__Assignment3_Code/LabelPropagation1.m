Data=load('TwoMoons.mat');
l=Data.Labeledtrain1;
u=Data.Unlabeledtrain1;
t=Data.test1;
%l=ll(:,2:17);
y1=Data.labeltarget;
%u=uu(:,2:17);
%t=tt(:,2:17);
%test=load('test123');
%x2=test(:,2:17);
Actual=Data.TestTargets1;

%CreateWeightMatrix;

create1;

%y=zeros(size(y1,1),2);
for i=1:size(y1,1)
    if y1(i,1)==1
         y(i,1)=0;
        y(i,2)=1;
    else 
            y(i,1)=1;
             y(i,2)=0;
    end
end
    
%y2=zeros(size(y12,1),2);
% for i=1:size(y12,1)
%     if y12(i,1)==1
%          y2(i,1)=0;
%         y2(i,2)=1;
%     else 
%           y2(i,1)=1;
%            y2(i,2)=0;
%     end
% end



[fu, fu_CMN] = harmonic_function(W1, y);


for i=1:size(fu_CMN,1)
if fu(i,1)>=fu(i,2)
    label(i,1)=-1;
else
    label(i,1)=1;
end
end

Predicted =label(end-size(t,1)+1:end);

Diff=Actual-Predicted;
n=sum(Diff(:)==0);
Acc=n*100/size(Actual,1)
