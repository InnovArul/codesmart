function [ cluster1,cluster2,cluster3,idx ] = clusteroutput(E,X)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
N = size(X,1);
outputvect=E;
[m,idx]=min(outputvect'); 
m=[m;idx];
k1=1;
k2=1;
k3=1;
for i=1:N
      tmp=idx(i);
      if tmp==1
          cluster1(k1,:)=X(i,:);
          k1=k1+1;
      end
        if tmp==2
            cluster2(k2,:)=X(i,:);
            k2=k2+1;
        end
        if tmp==3
            cluster3(k3,:)=X(i,:);
            k3=k3+1;
        end
end
end

