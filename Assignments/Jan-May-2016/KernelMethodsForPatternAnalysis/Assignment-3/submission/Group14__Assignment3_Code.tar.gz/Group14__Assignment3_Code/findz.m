function [Z ] = findz(c1,c2,c3 )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
n1=size(c1,1);
n2=size(c2,1);
n3=size(c3,1);
Z1=repmat([1 0 0], n1,1);
Z2=repmat([0 1 0], n2,1);
Z3=repmat([0 0 1], n3,1);
Z=[Z1;Z2;Z3];


end

