n=1;
for m=0.01:0.01:0.3
nuvalue(n,1)=m;

str=['-s 4 -t 2 -g 0.00095 -c 700 -n ' num2str(m)];

    %str=['-s 4 -t 2 -g 0.0005 -c 500 -n ' num2str(m)];
    %str=['-s 4 -t 2 -g 0.0007 -c 500 -n ' num2str(0.3)];
model=svmtrain(trainout,trainin,str);
[predictedVal, MSE, Prob_Val]=svmpredict(trainout,trainin,model);
trainerror(n,1)=MSE(2,1);

[predictedVal, MSE, Prob_Val]=svmpredict(valout,valin,model);
valerror(n,1)=MSE(2,1);

[predictedVal, MSE, Prob_Val]=svmpredict(testout,testin,model);
testerror(n,1)=MSE(2,1);
n=n+1;


end



%Complexity Vs Error
h=figure;
hold on;


kvalues=nuvalue;
err=trainerror;
xx = linspace(min(kvalues),max(kvalues),100);
    
    yy2 = spline(kvalues,err,xx); 
	%plot(xx,yy2,'LineWidth',3,'color','k')
    

plot(kvalues,err,'-b');
%scatter(kvalues,err,'*m');


valerr=valerror;
plot(kvalues,valerr,'-r');
%scatter(kvalues,valerr,'*m');
yy2 = spline(kvalues,valerr,xx); 
	%plot(xx,yy2,'LineWidth',3,'color','b')
    
    
testerr=testerror;
plot(kvalues,testerr,'-g');
%scatter(kvalues,testerr,'*m');

yy2 = spline(kvalues,testerr,xx); 
	%plot(xx,yy2,'LineWidth',3,'color','b')
    
xlabel('nu Value'); % x-axis label
ylabel('Mean Squared Error'); % y-axis label
title('nu Vs Mean Squared Error');
legend('Train Error','Validation Error','Test Error'); 
