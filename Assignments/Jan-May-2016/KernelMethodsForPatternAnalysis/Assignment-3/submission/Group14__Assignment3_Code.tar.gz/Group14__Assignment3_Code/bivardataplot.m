clear out;
clear x1;
clear x2;
h=figure;

%plot(val,valout,'*b');
x1=val(1:70,1);
x2=val(1:70,2);

valout=val(1:70,3);

[out, MSE, Prob_val]=svmpredict(valout,valin,model);
scatter3(x1,x2,valout,'*r');hold on;
scatter3(x1,x2,out,'*g'); 

[x11 x12]=meshgrid(min(x1):0.2:max(x1),min(x2):0.2:max(x2));

dataformesh=[x11(:) x12(:)];
[Yest, MSE, Prob_val]=svmpredict(zeros(size(dataformesh,1),1),dataformesh,model);
z=reshape(Yest,size(x11,1),size(x12,2));
surf(x11,x12,z,'Edgecolor','none');hold on;
xlabel('X1 values'); % x-axis label
ylabel('X2 values'); % y-axis label
zlabel('Y values (Outputs)'); % x-axis label
legend('Actual','Predicted','Function');
	
   title('Model Output for val Data');
   name='ModelOutput1.jpeg';
saveas(h,name);
%}
