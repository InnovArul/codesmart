clear all;
clc;
%% Loading Data
[ traindata,valdata,testdata,sizemat] = load_data();
data=traindata;
%class1=load('nonlinearly separable\class1_train.txt');
label1=zeros(sizemat(1,1),1);
label2=zeros(sizemat(1,2),1);
label3=zeros(sizemat(1,3),1);

%class2=load('nonlinearly separable\class2_train.txt');
%label2=zeros(length(class2),1);
%data=[class1;class2];
%label=[label1;label2];

%%Initalization
% % data=X;
a=randperm(size(data,1),size(data,2)+1);
a=a(1:3);
for i=1:length(a)
    c(i,:)=data(a(i),:);
end


%% Initializing grid
x1=min(data(:,1));
x2=max(data(:,1));
y1=min(data(:,2));
y2=max(data(:,2));
tempx=x1:0.2:x2;
tempy=y1:0.2:y2;
[A,B] = meshgrid(tempx, tempy);
temp1=cat(2,A',B');
g=reshape(temp1,[],2);

%% Plotting
labels=assign(data,c);
grid_labels=assign(g,c);
cl1=data(labels==1,:);
cl2=data(labels==2,:);
cl3=data(labels==3,:);
c(1,:)=mean(cl1);
c(2,:)=mean(cl2);
c(3,:)=mean(cl3);
grid_cl1=g(grid_labels==1,:);
grid_cl2=g(grid_labels==2, :);
grid_cl3=g(grid_labels==3, :);
plot(cl1(:,1), cl1(:,2), 'r.');
hold on
plot(cl2(:,1), cl2(:,2), 'g.');
plot(cl3(:,1), cl3(:,2), 'b.');
plot(grid_cl1(:,1), grid_cl1(:,2), 'c*');
plot(grid_cl2(:,1), grid_cl2(:,2), 'm*');
plot(grid_cl3(:,1), grid_cl3(:,2), 'y*');
plot(c(1,1),c(1,2), 'go-', 'linewidth', 5);
plot(c(2,1),c(2,2), 'yo-', 'linewidth', 5);
plot(c(3,1),c(3,2), 'bo-', 'linewidth', 5);
legend('Cluster1', 'Cluster2', 'Cluster3', 'Desicion Surface 1', 'Desicion Surface 2', 'Desicion Surface 3', 'Center1', 'Center2', 'Center3');
hold off

%% Run till particular number of iterations 
iter=1; %% mention the number of iteration for which you wants to run the code 
% % [labels, c]=mykmeans(data,c, iter);
for i=1:iter
figure;
labels=assign(data, c);
grid_labels=assign(g,c);
cl1=data(labels==1,:);
cl2=data(labels==2,:);
cl3=data(labels==3,:);
c(1,:)=mean(cl1);
c(2,:)=mean(cl2);
c(3,:)=mean(cl3);
grid_cl1=g(grid_labels==1,:);
grid_cl2=g(grid_labels==2, :);
grid_cl3=g(grid_labels==3, :);
plot(cl1(:,1), cl1(:,2), 'r.');
hold on
plot(cl2(:,1), cl2(:,2), 'g.');
plot(cl3(:,1), cl3(:,2), 'b.');
plot(grid_cl1(:,1), grid_cl1(:,2), 'c*');
plot(grid_cl2(:,1), grid_cl2(:,2), 'm*');
plot(grid_cl3(:,1), grid_cl3(:,2), 'y*');
plot(c(1,1),c(1,2), 'go-', 'linewidth', 5);
plot(c(2,1),c(2,2), 'yo-', 'linewidth', 5);
plot(c(3,1),c(3,2), 'bo-', 'linewidth', 5);
legend('Cluster1', 'Cluster2', 'Cluster3', 'Desicion Surface 1', 'Desicion Surface 2', 'Desicion Surface 3', 'Center1', 'Center2', 'Center3');
end
hold off


%% Run till convergence 
i=0;
while (1)
    i=i+1;
    labels1=labels;
    labels=assign(data, c);
    if (labels==labels1)
        break;
    end
iter=iter+1;
grid_labels=assign(g,c);
cl1=data(labels==1,:);
cl2=data(labels==2,:);
cl3=data(labels==3,:);
c(1,:)=mean(cl1);
c(2,:)=mean(cl2);
c(3,:)=mean(cl3);
grid_cl1=g(grid_labels==1,:);
grid_cl2=g(grid_labels==2, :);
grid_cl3=g(grid_labels==3, :);
plot(cl1(:,1), cl1(:,2), 'r.');
hold on
plot(cl2(:,1), cl2(:,2), 'g.');
plot(cl3(:,1), cl3(:,2), 'b.');
plot(grid_cl1(:,1), grid_cl1(:,2), 'c*');
plot(grid_cl2(:,1), grid_cl2(:,2), 'm*');
plot(grid_cl3(:,1), grid_cl3(:,2), 'y*');
plot(c(1,1),c(1,2), 'go-', 'linewidth', 5);
plot(c(2,1),c(2,2), 'yo-', 'linewidth', 5);
plot(c(3,1),c(3,2), 'bo-', 'linewidth', 5);
legend('Cluster1', 'Cluster2', 'Cluster3', 'Desicion Surface 1', 'Desicion Surface 2', 'Desicion Surface 3', 'Center1', 'Center2', 'Center3');
hold off
end