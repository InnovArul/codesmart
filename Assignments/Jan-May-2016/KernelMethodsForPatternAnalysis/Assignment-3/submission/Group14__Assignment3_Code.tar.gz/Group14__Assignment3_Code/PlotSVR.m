epsilon=  0.715564
[out, MSE, Prob_Val]=svmpredict(trainout,trainin,model);
out1=out-epsilon.*ones(size(out,1),1);
out2=out+epsilon.*ones(size(out,1),1);


h=figure;
	%plot(trainin,trainout,'*y'); hold on;
 
	plot(trainin,trainactual,'.'); hold on;
	xx = linspace(min(trainin),max(trainin),100);
	yy = spline(trainin,trainactual,xx); 
    yy1 = spline(trainin,out,xx); 
	plot(trainin,out,'.',xx,yy,xx,yy1,'LineWidth',2)
    
    %yy = spline(testin,testactual,xx); 
    
    yy2 = spline(testin,out1,xx); 

	plot(testin,out1,'.',xx,yy,xx,yy2,'LineWidth',2)
    
    %yy = spline(testin,testactual,xx); 
    
    yy3 = spline(testin,out,xx); 
	plot(testin,out2,'.',xx,yy,xx,yy,'LineWidth',2)
   
    xlabel('X Values'); % x-axis label
	ylabel('Y Values(Estimated)'); % y-axis label
    legend('Synthesized','Predicted','Actual');
	saveas(h,'testregression.jpeg');



[out, MSE, Prob_Val]=svmpredict(testout,testin,model);

epsilon=  0.715564

out1=out-epsilon.*ones(size(out,1),1);
out2=out+epsilon.*ones(size(out,1),1);

h=figure;
	%plot(trainin,trainout,'*y'); hold on;
 
	plot(testin,testactual,'.'); hold on;
	xx = linspace(min(testin),max(testin),100);
	yy = spline(testin,testactual,xx); 
    yy1 = spline(testin,out,xx); 
	plot(testin,out,'.',xx,yy,xx,yy1,'LineWidth',2)
    
    %yy = spline(testin,testactual,xx); 
    
    yy2 = spline(testin,out1,xx); 
	plot(testin,out1,'.',xx,yy,xx,yy2,'LineWidth',2)
    
    %yy = spline(testin,testactual,xx); 
    
    yy3 = spline(testin,out,xx); 
	plot(testin,out2,'.',xx,yy,xx,yy,'LineWidth',2)
   
    xlabel('X Values'); % x-axis label
	ylabel('Y Values(Estimated)'); % y-axis label
    legend('Synthesized','Predicted','Actual');
	saveas(h,'regression.jpeg');


