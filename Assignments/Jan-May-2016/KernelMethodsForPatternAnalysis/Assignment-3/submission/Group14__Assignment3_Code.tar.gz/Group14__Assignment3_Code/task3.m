clear all;
%% Initializing data and evaluating kernel matrix (One time Only)
[ traindata,valdata,testdata,sizemat] = load_data();
X=traindata;
% % rand=randperm(850);
% % for i=1:850
% %     temp=rand(i);
% %     data(i,:)=X(temp,:);
% % end
% % X=data;
figure(1);hold off
plot(X(:,1),X(:,2),'ko');

N = size(X,1);
Ke = zeros(N);
gam = 0.75;
for n = 1:N
    for n2 = 1:N
        Ke(n,n2) = exp(-gam*sum((X(n,:)-X(n2,:)).^2));
    end
end

converged = 0;
% Assign all objects into one cluster except one
% Kernel K-means is *very* sensitive to initial conditions.  Try altering
% this initialisation to see the effect.
K = 3;
Z1 = repmat([1 0 0],50,1);
Z2 = repmat([0 1 0],75,1);
Z3 = repmat([0 0 1],25,1);
Z4 = repmat([1 0 0],50,1);
Z5 = repmat([0 1 0],200,1);
Z6 = repmat([0 0 1],100,1);
Z7 = repmat([1 0 0],100,1);
Z8 = repmat([0 1 0],150,1);
Z9 = repmat([0 0 1],100,1);
Z=[Z1;Z2;Z3;Z4;Z5;Z6;Z7;Z8;Z9];
s = sum(X.^2,2);
pos = find(s==min(s));
Z(pos,:) = [0 1 0];
di = zeros(N,K);
cols = {'r','g','b'};

%%  Initializing Grid points (Only One time)
data=X;
x1=min(data(:,1));
x2=max(data(:,1));
y1=min(data(:,2));
y2=max(data(:,2));
tempx=x1:0.1:x2;
tempy=y1:0.1:y2;
[A,B] = meshgrid(tempx, tempy);
temp1=cat(2,A',B');
g=reshape(temp1,[],2);
N1 = size(g,1);


% % figure(1);
% % for k = 1:K
% %     pos = find(Z(:,k));
% %     plot(X(pos,1),X(pos,2),'o','markerfacecolor',cols{k});
% %     hold on
% % end
%% Grid-Data (Only One time)
for n = 1:N1
    for n2 = 1:N
        Ke_new(n,n2) = exp((-1)*sum((g(n,:)-X(n2,:)).^2)/gam);
    end
end

%% Grid-Grid (Only One time)
for n = 1:N1
    for n2 = 1:N1
        Kg(n,n2) = exp((-1)*sum((g(n,:)-g(n2,:)).^2)/gam);
    end
end


%% Only one time 
diagonal=diag(Kg);
di1 = zeros(N1,K);
cols1 = {'y','m', 'c'};
Nk = sum(Z,1);
% % for i=1:20

Z1=zeros(size(g,1),K);

while ~converged %% No need to rum the loop
%% Run it for multiple iteration, after each iteration evaluate labels of grid.
    Nk = sum(Z,1);
    for k = 1:K
        % Compute kernelised distance
        di(:,k) = diag(Ke) - (2/(Nk(k)))*sum(repmat(Z(:,k)',N,1).*Ke,2) + ...
            Nk(k)^(-2)*sum(sum((Z(:,k)*Z(:,k)').*Ke));
    end
    oldZ = Z;
    Z = (di == repmat(min(di,[],2),1,K));
    Z = 1.0*Z;

    figure;
    for k = 1:K
        pos = find(Z(:,k));
        plot(X(pos,1),X(pos,2),'ko','markerfacecolor',cols{k});
        hold on
    end
    






%% Multiple times after each iteration of before thing 
    for k = 1:K
        % Compute kernelised distance
        di1(:,k) = diagonal - (2/(Nk(k)))*sum(repmat(Z(:,k)',N1,1).*Ke_new,2) + Nk(k)^(-2)*sum(sum((Z(:,k)*Z(:,k)').*Ke));
    end
    oldZg = Z1;
    Z1 = (di1 == repmat(min(di1,[],2),1,K));
    Z1 = 1.0*Z1;
% %     figure1 = figure;
    for k = 1:K
        pos = find(Z1(:,k));
        plot(g(pos,1),g(pos,2),[cols1{k} '.']); 
       hold on
% %         plot(X(:,1),X(:,2),'k*','MarkerSize',5);
% %         s=['plot_kernel_new',num2str(i),'.jpg'];
        % % saveas(figure1,s)
    end
    legend('Class 1', 'Class 2', 'Class 3', 'Decision Surface 1', 'Decision Surface 2', 'Decision Surface 3');
    hold off
    if sum(sum(oldZg~=Z1))==0
        converged = 1;
    end


end
