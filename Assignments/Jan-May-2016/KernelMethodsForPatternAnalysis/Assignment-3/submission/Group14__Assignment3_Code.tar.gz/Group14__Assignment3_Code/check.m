clear all;
[ traindata,valdata,testdata,sizemat] = load_data();
X=traindata;
%{
figure(1);hold off
plot(X(:,1),X(:,2),'ko');

N = size(X,1);
Ke = zeros(N);
gam = 1;
for n = 1:N
    for n2 = 1:N
        Ke(n,n2) = exp(-gam*sum((X(n,:)-X(n2,:)).^2));
    end
end
%}
N = size(X,1);
gam = 0.5;
c1=X(1,:);
c2=X(300,:);
c3=X(50,:);

converged=0;
previous= zeros(N,1);
previous=previous';
while ~converged
    outputvect=[];
    for i=1:N
        d1(i)=exp(-gam*sum((X(i,:)-c1).^2));
        d2(i)=exp(-gam*sum((X(i,:)-c2).^2));
        d3(i)=exp(-gam*sum((X(i,:)-c3).^2));
    end
    outputvect=[outputvect;d1;d2;d3];
    [m,idx]=max(outputvect);

m=[m;idx];
k1=1;
k2=1;
k3=1;
for i=1:N
      tmp=idx(i);
      if tmp==1
          cluster1(k1,:)=X(i,:);
          k1=k1+1;
      end
        if tmp==2
            cluster2(k2,:)=X(i,:);
            k2=k2+1;
        end
        if tmp==3
            cluster3(k3,:)=X(i,:);
            k3=k3+1;
        end
end
if idx==previous
    converged=1;
end
previous=idx;

c1=mean(cluster1);
c2=mean(cluster2);
c3=mean(cluster3);
end
hold on
scatter(cluster1(:,1),cluster1(:,2),'r');
scatter(cluster2(:,1),cluster2(:,2),'g');
scatter(cluster3(:,1),cluster3(:,2),'b');
hold off