Data=importdata('FinalUniData.txt');
P=Data;
Data=Data(randperm(size(Data,1)),:);
train=Data(1:24,:);
val=Data(25:32,:);
test=Data(33:40,:);

