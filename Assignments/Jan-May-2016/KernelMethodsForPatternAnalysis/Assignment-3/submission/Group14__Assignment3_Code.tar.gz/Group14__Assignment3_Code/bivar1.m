
close all;
%Data=load('FinalUniData.mat');
train=importdata('group14_train1000.txt');
val=importdata('group14_val.txt');
test=importdata('group14_test.txt');
b=size(train,1);

trainin=train(1:200,1:2);
valin=val(1:70,1:2);
testin=test(1:70,1:2);

trainout=train(1:200,3);
valout=val(1:70,3);
testout=test(1:70,3);


n=1;



% m=1;
% for n=0.1:0.01:0.3
%     p=1;
%     for g=1:1:100
%  str=['-s 4 -t 2 -g' num2str(g) '-c 1 -n ' num2str(n)];
% model=svmtrain(trainout,trainin,str);
% 
% [out, MSE, Prob_Val]=svmpredict(valout,valin,model);
% GG(p,1)=g;
% error(m,p)=MSE(2,1);
% p=p+1;
%     end
%     NN(m,1)=n;
%     m=m+1;
% end
% 
% mini =min(min(error))
% 
% for n=1:m-1
%     for g=1:p-1
%     if(error(n,g)==mini)
%         nu=NN(n,1)
%         gamma=GG(g,1)
%     end
%     end
% end

 %str=['-s 4 -t 2 -g 0.00095 -c 700 -n ' num2str(0.3)];
 str=['-s 4 -t 2 -g 0.01 -c 700 -n ' num2str(0.23)]
model=svmtrain(trainout,trainin,str);

%[out, MSE, Prob_Val]=svmpredict(valout,valin,model);
%[out, MSE, Prob_Val]=svmpredict(trainout,trainin,model);

[predictedVal, MSE, Prob_Val]=svmpredict(trainout,trainin,model);

[predictedVal, MSE, Prob_Val]=svmpredict(valout,valin,model);


[predictedVal, MSE, Prob_Val]=svmpredict(testout,testin,model);

