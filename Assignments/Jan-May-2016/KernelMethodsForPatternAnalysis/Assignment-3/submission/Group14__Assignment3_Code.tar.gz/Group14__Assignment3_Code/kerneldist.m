function [ E] = kerneldist(X,Z,Ke)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
N = size(X,1);
M=3;
for i =1:N
    for k=1:M
        tmp=Z(:,k);
        tmpsum=0;
        for j=1:N
           tmpsum=tmpsum+tmp(j)*Ke(i,j);   
        end
        tmpmean=(2*tmpsum)/sum(tmp);
        tmpsum=0;
        for j=1:N
            for l=1:N
                tmpsum=tmpsum+tmp(j)*tmp(l)*Ke(j,l);
            end        
        end
        tmplast=tmpsum/(sum(tmp)*sum(tmp));
        E(i,k)=(Ke(i,i)-tmpmean+tmplast);
    end
end


end

