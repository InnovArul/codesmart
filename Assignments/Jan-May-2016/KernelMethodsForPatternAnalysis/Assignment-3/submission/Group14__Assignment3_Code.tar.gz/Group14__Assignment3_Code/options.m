classdef options
    %OPTIONS Summary of this class goes here
    %   Detailed explanation goes here
    
    properties( Constant )
        DATASET3 = 1
        DATASET4 = 2
        GRAPHDATA = 3
    end
    
    methods
    end
    
end

