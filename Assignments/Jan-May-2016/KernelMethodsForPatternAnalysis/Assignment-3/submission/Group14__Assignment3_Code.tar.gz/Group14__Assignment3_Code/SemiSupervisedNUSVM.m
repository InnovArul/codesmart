input=importdata('Labeledtrain1');
x=input(:,2:17);
y=input(:,1);
x22=importdata('Unlabeledtrain1');
x2=x22(:,2:17);
y2=x22(:,1);
flag=1;
iter=0;
while(size(x2,1)>0 && flag==1)
    iter=iter+1;
%model=svmtrain(y,x,'-s 1 -t 1 -d 2 -r 0.55 -n 0.23 -b 1 -h 0');
model=svmtrain(y,x,'-s 1 -t 2 -g 0.05 -n 0.23 -b 1 ');
%predicted=svmpredict(y2,x2,model);
thr=3.0;
[predict_label, accuracy, prob_values] = svmpredict(y2,x2,model,'-b 1');
for i=1:size(y2,1)
    if(prob_values(i,1)>=prob_values(i,2))
        ratio=prob_values(i,1)/prob_values(i,2);
        if(ratio>thr)
            y2(i,1)=1;
        end
    else (prob_values(i,1)<prob_values(i,2))
          ratio=prob_values(i,2)/prob_values(i,1);
        if(ratio>thr)
            y2(i,1)=-1;
        end
    end
end
clear x2;
n=1;
flag=0;
m=size(x,1)+1;
for i=1:size(x22,1)
if y2(i,1)==0
    x2(n,:)=x22(i,2:17);
    n=n+1;
else
    x(m,:)=x22(i,2:17);
    y(m,:)=y2(i,1);
    m=m+1;
    flag=1;
end
end
y2=zeros(size(x2,1),1);
clear x22;
x22=[y2 x2];
end
iter
t11=importdata('test1');
t1=t11(:,2:17);
t2=importdata('TestTargets');
[predict_label, accuracy, prob_values] = svmpredict(t2,t1,model,'-b 1');
