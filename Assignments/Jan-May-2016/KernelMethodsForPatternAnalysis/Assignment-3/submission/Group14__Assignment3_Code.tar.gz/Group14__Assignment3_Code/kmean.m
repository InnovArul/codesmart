clear all;
[ traindata,valdata,testdata,sizemat] = load_data();
X=traindata;
data=X;
plot(X(:,1),X(:,2),'ko');
N = size(X,1);

a=randperm(size(X,1),size(X,2)+1);
a=a(1:3);
c1=data(a(1),:);
c2=data(a(2),:);
c3=data(a(3),:);
converged=0;
previous= zeros(N,1);
previous=previous';
iteration=0;
%grid initialization
x1=min(data(:,1));
x2=max(data(:,1));
y1=min(data(:,2));
y2=max(data(:,2));
tempx=x1:0.2:x2;
tempy=y1:0.2:y2;
[A,B] = meshgrid(tempx, tempy);
temp1=cat(2,A',B');
g=reshape(temp1,[],2);
N1=size(g,1);

while ~converged
    iteration=iteration+1;
    outputvect=[];
    cluster1=[];
    cluster2=[];
    cluster3=[];
    gcl1=[];
    gcl2=[];
      gcl3=[];
    
    
    for i=1:N
        d1(i)=norm(X(i,:)-c1);
        d2(i)=norm(X(i,:)-c2);
        d3(i)=norm(X(i,:)-c3);
    end
    outputvect=[outputvect;d1;d2;d3];
    [m,idx]=min(outputvect);

m=[m;idx];
k1=1;
k2=1;
k3=1;
for i=1:N
      tmp=idx(i);
      if tmp==1
          cluster1(k1,:)=X(i,:);
          k1=k1+1;
      end
        if tmp==2
            cluster2(k2,:)=X(i,:);
            k2=k2+1;
        end
        if tmp==3
            cluster3(k3,:)=X(i,:);
            k3=k3+1;
        end
end
 outputvect1=[];
  for i=1:N1
        d11(i)=norm(g(i,:)-c1);
        d21(i)=norm(g(i,:)-c2);
        d31(i)=norm(g(i,:)-c3);
    end
    outputvect1=[outputvect1;d11;d21;d31];
    [m1,idx1]=min(outputvect1);

m=[m1;idx1];
k1=1;
k2=1;
k3=1;
for i=1:N
      tmp=idx1(i);
      if tmp==1
          gcl1(k1,:)=g(i,:);
          k1=k1+1;
      end
        if tmp==2
            gcl2(k2,:)=g(i,:);
            k2=k2+1;
        end
        if tmp==3
            gcl3(k3,:)=g(i,:);
            k3=k3+1;
        end
end


if idx==previous
    converged=1;
end
previous=idx;

c1=mean(cluster1);
c2=mean(cluster2);
c3=mean(cluster3);
figure;
hold on
scatter(gcl1(:,1),gcl1(:,2),'*');
scatter(gcl2(:,1),gcl2(:,2),'*');
scatter(gcl3(:,1),gcl3(:,2),'*');

scatter(cluster1(:,1),cluster1(:,2),'r');
scatter(cluster2(:,1),cluster2(:,2),'g');
scatter(cluster3(:,1),cluster3(:,2),'b');
hold off
end
